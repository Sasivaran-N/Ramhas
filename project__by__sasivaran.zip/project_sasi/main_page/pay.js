function showLoading(event, button) {
    event.preventDefault(); // Prevent form submission
  
     button.innerHTML = "Processing Payment...";
     
    // Change to the desired duration in milliseconds
    setTimeout(function() {
        button.innerHTML = "Payment completed.";
      }, 3000);
  }
    
  
  function  preventDefault()
  {
      var CardNumber = document.getElementById("card-number").value;
      var CardHolder = document.getElementById("card-holder").value;
      var expiryDate = document.getElementById("expiry-date").value;
      var cvv = document.getElementById("cvv").value;
      if(CardNumber ==''||CardNumber.length <16)
      {
          alert("Please Enter Valid CardNumber.");
      }
      else if(CardHolder=='')
      {
          alert("Enter the Card Holder Name");
      }
      else if(expiryDate==''||expiryDate.length<5)
      {
          alert("Enter the Valid Card expiryDate");
      }
      else if(cvv==''||cvv<3)
      {
          alert("Enter the Valid CVV ");
      }
      else
      {
        alert('Payment Sucessfull.... ');
    
        alert("Thank's for your Order... \n Your Order Reach you soon...");
      
          }
  };
 
 