const btnClose=document.querySelector('#cart-close');
btnClose.addEventListener('click',()=>{
	close();
    window.location = "ramhasa.html";

	function close() {
		alert("Login to Easy Accessibility");
	}
});


function login()
	{
		var uname = document.getElementById("email").value;
		var pwd = document.getElementById("pwd1").value;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(uname =='')
		{
			alert("Please Enter Valid user Id.");
		}
		else if(pwd=='')
		{
        	alert("Enter the Password");
		}
		else if(!filter.test(uname))
		{
			alert("Enter valid email id ");
		}
		else if(pwd.length < 6 || pwd.length == 0)
		{
			alert("Password min length is 6 ");
		}
		else
		{
	alert('Thank You for Login & You are Redirecting to Ramhas Page');
  //Redirecting to other page or webste code or you can set your own html page.
       window.location = "ramhasa.html";
			}
	}
	//Reset Inputfield code.
	function clearFunc()
	{
		document.getElementById("email").value="";
		document.getElementById("pwd1").value="";
	}	