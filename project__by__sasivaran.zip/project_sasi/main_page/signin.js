
const btnClose=document.querySelector('#cart-close');
btnClose.addEventListener('click',()=>{
	close();
    window.location = "ramhasa.html";

	function close() {
		alert("Login to Easy Accessibility");
	}
});

function  signup()
	{
		var uname = document.getElementById("email").value;
		var pwd1 = document.getElementById("pwd1").value;
        var pwd2 = document.getElementById("pwd2").value;
		var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if(uname =='')
		{
			alert("Please Enter Valid user Id.");
		}
		else if(pwd1=='')
		{
        	alert("Enter the Password");
		}
		else if(!filter.test(uname))
		{
			alert("Enter valid email id ");
		}
		else if(pwd1.length < 6 || pwd1.length == 0)
		{
			alert("Password min length is 6 ");
		}
        else if(pwd1!==pwd2)
		{
			alert("Enter Same Password As Password ");
		}
		else
		{
	alert('Thank You for Signup & You are Redirecting to Ramhas Login Page');
  //Redirecting to other page or webste code or you can set your own html page.
       window.location = "login1.html";
			}
	}
	//Reset Inputfield code.
	function clearFunc()
	{
		document.getElementById("email").value="";
		document.getElementById("pwd1").value="";
	}	